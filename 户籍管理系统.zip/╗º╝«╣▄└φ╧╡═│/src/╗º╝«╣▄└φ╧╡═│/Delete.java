package ��������ϵͳ;

import static ��������ϵͳ.Filemain.list;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Delete extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2700441316276813588L;
	private JPanel contentPane;
	private JTextField textField_1;
	private JTextField textField_3;

	/**
	 * Create the frame.
	 */
	public Delete() {
		setTitle("\u5220\u9664\u4EBA\u5458\u4FE1\u606F");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 250, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 416, 253);
		contentPane.add(panel);
		panel.setLayout(null);

		textField_1 = new JTextField();
		textField_1.setBounds(173, 70, 97, 21);
		panel.add(textField_1);
		textField_1.setColumns(10);

		textField_3 = new JTextField();
		textField_3.setBounds(173, 121, 97, 21);
		panel.add(textField_3);
		textField_3.setColumns(10);

		JButton btnNewButton = new JButton("\u5220\u9664");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String name = textField_1.getText();
				String id = textField_3.getText();
				if (list.size() > 0) {
					for (int i = 0; i < list.size(); i++) {
						Person p = list.get(i);
						if (id.equals(p.getID()) && name.equals(p.getName())) {
							list.remove(i);
							new Filew().writePer();
							JOptionPane.showMessageDialog(null, "ɾ���ɹ�", "ɾ�����", JOptionPane.PLAIN_MESSAGE);

							return;
						}
						if (i == list.size() - 1) {
							JOptionPane.showMessageDialog(null, "������Ϣ�������򲻴��ڸ���Ա��Ϣ", "����", JOptionPane.ERROR_MESSAGE);
						}
					}
				} else {
					JOptionPane.showMessageDialog(null, "û������", "����", JOptionPane.ERROR_MESSAGE);

				}

			}
		});
		btnNewButton.setBounds(43, 188, 97, 38);
		panel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				textField_1.setText("");
				textField_3.setText("");
			}
		});
		btnNewButton_1.setBounds(159, 188, 97, 38);
		panel.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("\u53D6\u6D88");
		btnNewButton_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new AdminDL().setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(282, 188, 97, 38);
		panel.add(btnNewButton_2);

		JLabel lblNewLabel = new JLabel("\u59D3 \u540D\uFF1A");
		lblNewLabel.setBounds(105, 73, 58, 15);
		panel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("ID \u53F7\uFF1A");
		lblNewLabel_1.setBounds(105, 124, 58, 15);
		panel.add(lblNewLabel_1);
	}
}
