package ��������ϵͳ;

import java.util.Objects;

public class Person {
	private String huhao;// ����
	private String name;// ����
	private String sex;// �Ա�
	private String ID;// ����֤��
	private String huzhi;// ����
	private String date;// Ǩ��ʱ��

	public Person() {
	}

	public Person(String huhao, String name, String sex, String iD, String huzhi, String date) {
		super();
		this.huhao = huhao;
		this.name = name;
		this.sex = sex;
		ID = iD;
		this.huzhi = huzhi;
		this.date = date;
	}

	@Override
	public String toString() {
		return "Person [huhao=" + huhao + ", name=" + name + ", sex=" + sex + ", ID=" + ID + ", huzhi=" + huzhi
				+ ", date=" + date + "]";
	}

	public String getHuhao() {
		return huhao;
	}

	public void setHuhao(String huhao) {
		this.huhao = huhao;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getHuzhi() {
		return huzhi;
	}

	public void setHuzhi(String huzhi) {
		this.huzhi = huzhi;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public int hashCode() {
		return Objects.hash(huhao, name, sex, ID, huzhi, date);
	}

}
