package ��������ϵͳ;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class IDCard extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4430437823179003927L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	String s[] = null;

	/**
	 * Create the frame.
	 */
	FileReader fr = null;
	BufferedReader br = null;

	public IDCard() {
		setTitle("\u8EAB\u4EFD\u8BC1\u7533\u8BF7");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 250, 450, 360);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u4E2A\u4EBA\u4FE1\u606F\uFF1A");
		lblNewLabel.setBounds(10, 10, 87, 15);
		contentPane.add(lblNewLabel);

		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(39, 35, 356, 241);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("\u59D3\u540D\uFF1A");
		lblNewLabel_1.setBounds(16, 23, 58, 15);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("\u6027\u522B\uFF1A");
		lblNewLabel_2.setBounds(16, 55, 58, 15);
		panel.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("\u6C11\u65CF\uFF1A");
		lblNewLabel_3.setBounds(110, 55, 58, 15);
		panel.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("\u51FA\u751F\u65E5\u671F\uFF1A");
		lblNewLabel_4.setBounds(16, 86, 72, 15);
		panel.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("\u4F4F\u5740\uFF1A");
		lblNewLabel_5.setBounds(16, 111, 58, 15);
		panel.add(lblNewLabel_5);

		textField = new JTextField();// ����
		textField.setBounds(50, 20, 66, 21);
		textField.setOpaque(false);
		panel.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();// �Ա�
		textField_1.setBounds(53, 52, 35, 21);
		textField_1.setOpaque(false);
		panel.add(textField_1);
		textField_1.setColumns(10);

		textField_2 = new JTextField();// ����
		textField_2.setBounds(146, 52, 66, 21);
		textField_2.setOpaque(false);
		panel.add(textField_2);
		textField_2.setColumns(10);

		textField_3 = new JTextField();// ��������
		textField_3.setBounds(84, 83, 128, 21);
		textField_3.setOpaque(false);
		panel.add(textField_3);
		textField_3.setColumns(10);

		textField_4 = new JTextField();
		textField_4.setBounds(79, 213, 106, 21);
		textField_4.setOpaque(false);
		panel.add(textField_4);
		textField_4.setColumns(10);

		JLabel lblNewLabel_6 = new JLabel("\u8054\u7CFB\u7535\u8BDD\uFF1A");
		lblNewLabel_6.setBounds(16, 216, 66, 15);
		panel.add(lblNewLabel_6);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(50, 111, 296, 65);
		panel.add(scrollPane);

		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		textArea.setOpaque(false);

		JLabel lblNewLabel_7 = new JLabel("\u516C\u6C11\u8EAB\u4EFD\u8BC1\u53F7\u7801\uFF1A");
		lblNewLabel_7.setBounds(16, 186, 100, 15);
		panel.add(lblNewLabel_7);

		textField_5 = new JTextField();
		textField_5.setBounds(110, 186, 236, 21);
		textField_5.setOpaque(false);
		panel.add(textField_5);
		textField_5.setColumns(10);

		JButton btnNewButton = new JButton("\u786E\u8BA4");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String s0 = textField.getText();
				String s1 = textField_1.getText();
				String s2 = textField_2.getText();
				String s3 = textField_3.getText();
				String s4 = textField_4.getText();// �绰
				String s5 = textArea.getText();// סַ
				String s6 = textField_5.getText();
				String str = s0 + " " + s1 + " " + s2 + " " + s3 + " " + s5 + " " + s6 + " " + s4;
				boolean bool = true;
				try {
					fr = new FileReader("D:\\ID.txt");
					br = new BufferedReader(fr);
					String Line = "";
					while ((Line = br.readLine()) != null) {
						s = Line.split(" ");
						if (!s[0].equals(s6)) {
							bool = true;
						} else {
							bool = false;
							break;
						}
					}

					fr.close();
					br.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				if (bool) {
					new Filew().writeID(str);
					JOptionPane.showMessageDialog(null, "����ɹ� ��Ⱥ���ȡʱ��֪ͨ��", "��ʾ��Ϣ", JOptionPane.PLAIN_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null, "������ \n�����ظ����룡����", "��ʾ��Ϣ", JOptionPane.PLAIN_MESSAGE);
				}
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
				textField_4.setText("");
				textField_5.setText("");
				textArea.setText("");
			}
		});
		btnNewButton.setBounds(86, 279, 97, 34);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.setBounds(261, 279, 97, 34);
		contentPane.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new UseInquiry().setVisible(true);
				dispose();
			}
		});

	}
}
