package ��������ϵͳ;

import static ��������ϵͳ.Filemain.list;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Sort extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4472735803586424893L;
	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public Sort() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

	}

	public void sort() {
		// TODO Auto-generated method stub
		Person p = new Person();
		Person p1 = new Person();
		for (int i = 0; i < list.size() - 1; i++) {
			for (int j = i + 1; j < list.size(); j++) {
				if (Integer.valueOf(list.get(i).getHuhao()) > Integer.valueOf(list.get(j).getHuhao())) {
					p = list.get(i);
					p1 = list.get(j);
					list.set(i, p1);
					list.set(j, p);

				}
			}

		}
		new Filew().writePer();
		new Printf().setVisible(true);
		/*
		 * for (int g = 0; g < list.size(); g++) { System.out.println(list.get(g)); }
		 */
	}
}