package ��������ϵͳ;

import static ��������ϵͳ.Filemain.list;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Printf extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4136448766202041264L;
	private JPanel contentPane;
	private JTable table;

	/**
	 * Create the frame.
	 */
	public Printf() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\yang\\Pictures\\Camera Roll\\heisewenli-2.jpg"));
		setTitle("\u5168\u90E8\u4EBA\u53E3\u4FE1\u606F");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 250, 450, 350);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 41, 426, 198);
		contentPane.add(scrollPane);

		table = new JTable();
		table.setEnabled(false);
		String col[] = { "  \u6237  \u53F7", "  \u59D3  \u540D", "  \u6027  \u522B", "  ID  \u53F7", "  \u6237  \u5740",
				"\u8FC1\u5165\u65F6\u95F4" };
		DefaultTableModel defaultTableModel = new DefaultTableModel(col, 0);
		// ����sList�÷��ͼ��ϵ����ݣ��������ݷ���strRow�����У�ÿ�����ݣ�
		for (int i = 0; i < list.size(); i++) {
			String huhao = list.get(i).getHuhao();
			String name = list.get(i).getName();
			String sex = list.get(i).getSex();
			String id = list.get(i).getID();
			String huzhi = list.get(i).getHuzhi();
			String date = list.get(i).getDate();
			String[] strRow = { huhao, name, sex, id, huzhi, date };

			// ����������
			defaultTableModel.addRow(strRow);
		}

		// ���ñ�������ģ��
		table.setModel(defaultTableModel);
		scrollPane.setViewportView(table);

		JButton btnNewButton = new JButton("\u8FD4\u56DE");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new AdminDL().setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(229, 268, 97, 35);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u6392\u5E8F");
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Sort().sort();
				dispose();
			}
		});
		btnNewButton_1.setBounds(69, 268, 97, 35);
		contentPane.add(btnNewButton_1);

		JLabel lblNewLabel = new JLabel("\u4EBA\u53E3\u603B\u6570\uFF1A");
		lblNewLabel.setBounds(20, 10, 80, 21);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel(String.valueOf(list.size()));// �˿�����
		lblNewLabel_1.setBounds(83, 13, 58, 15);
		contentPane.add(lblNewLabel_1);

	}
}
