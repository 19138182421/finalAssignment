package ��������ϵͳ;

import static ��������ϵͳ.Filemain.list;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class UseInquiry extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2373226968106499768L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table_1;

	/**
	 * Create the frame.
	 */
	public UseInquiry() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\yang\\Pictures\\Camera Roll\\heisewenli-2.jpg"));
		setTitle(
				"\u7528\u6237\u754C\u9762\uFF08\u4EC5\u9650\u67E5\u8BE2\u53CA\u8EAB\u4EFD\u8BC1\u529E\u7406\u529F\u80FD\uFF09");
		setBackground(Color.LIGHT_GRAY);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 180, 647, 484);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(-14, 10, 613, 427);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u59D3\u540D\uFF1A");
		lblNewLabel.setBounds(134, 85, 52, 15);
		panel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("ID \u53F7\uFF1A");
		lblNewLabel_1.setBounds(291, 85, 47, 15);
		panel.add(lblNewLabel_1);

		textField = new JTextField();// ����
		textField.setBounds(183, 82, 83, 21);
		textField.setOpaque(false);
		panel.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(340, 82, 89, 21);
		textField_1.setOpaque(false);
		panel.add(textField_1);
		textField_1.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setEnabled(false);
		scrollPane.setBounds(89, 247, 445, 116);
		panel.add(scrollPane);

		table_1 = new JTable();
		String col[] = { "\u6237\u53F7", "\u59D3\u540D", "\u6027\u522B", "ID\u53F7", "\u6237\u5740",
				"\u8FC1\u5165\u65F6\u95F4" };// ���ñ�ͷ
		// ����Model��ű�ͷ 0��ʾrowcount ����������
		DefaultTableModel defaultTableModel = new DefaultTableModel(col, 0);
		table_1.setModel(defaultTableModel);// ��������model
		scrollPane.setViewportView(table_1);// ���ñ���ɼ���
		JButton btnNewButton = new JButton("\u786E\u5B9A");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				defaultTableModel.getDataVector().clear();// ��ձ����������
				String name1 = textField.getText();
				String huhao1 = null;
				// ����sList�÷��ͼ��ϵ����ݣ��������ݷ���strRow�����У�ÿ�����ݣ�
				if (list.size() > 0) {
					for (int i = 0; i < list.size(); i++) {
						Person p = list.get(i);
						if (name1.equals(p.getName()) && textField_1.getText().equals(p.getID())) {
							// ��ȡ����
							huhao1 = p.getHuhao();
							for (int j = 0; j < list.size(); j++) {
								Person p1 = list.get(j);
								if (huhao1.equals(p1.getHuhao())) {
									String huhao = list.get(j).getHuhao();
									String name = list.get(j).getName();
									String sex = list.get(j).getSex();
									String id = list.get(j).getID();
									String huzhi = list.get(j).getHuzhi();
									String date = list.get(j).getDate();
									String[] strRow = { huhao, name, sex, id, huzhi, date };

									// ����������
									defaultTableModel.addRow(strRow);
								} else {
									continue;
								}
							}
							table_1.setModel(defaultTableModel);
							scrollPane.setViewportView(table_1);

							return;
						}
						if (i == list.size() - 1) {
							JOptionPane.showMessageDialog(null, "������Ϣ����������Ա������", "����", JOptionPane.ERROR_MESSAGE);
						}
					}
				} else {
					JOptionPane.showMessageDialog(null, "û������", "����", JOptionPane.ERROR_MESSAGE);

				}

			}
		});
		btnNewButton.setBounds(89, 159, 106, 35);
		panel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u9000\u51FA");
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(437, 159, 97, 35);
		panel.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("\u91CD\u7F6E");
		btnNewButton_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
			}
		});
		btnNewButton_2.setBounds(269, 159, 97, 35);
		panel.add(btnNewButton_2);

		JLabel lblNewLabel_2 = new JLabel("\u8EAB\u4EFD\u8BC1\u7533\u8BF7\u70B9\u51FB\u6B64\u5904");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.print("sd");
				new IDCard().setVisible(true);
				dispose();
			}
		});
		lblNewLabel_2.setForeground(Color.BLUE);
		lblNewLabel_2.setBounds(489, 26, 138, 15);
		panel.add(lblNewLabel_2);

	}
}
