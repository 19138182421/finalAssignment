package ��������ϵͳ;

import static ��������ϵͳ.Filemain.list;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Inquiry extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2470820617447753135L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table_1;

	/**
	 * Create the frame.
	 */
	public Inquiry() {
		setTitle("\u67E5\u8BE2\u4EBA\u53E3\u4FE1\u606F");
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\yang\\Pictures\\Camera Roll\\heisewenli-2.jpg"));

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 250, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 426, 253);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u59D3\u540D\uFF1A");
		lblNewLabel.setBounds(43, 10, 42, 15);
		panel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("ID \u53F7\uFF1A");
		lblNewLabel_1.setBounds(216, 10, 59, 15);
		panel.add(lblNewLabel_1);

		textField = new JTextField();// ����
		textField.setBounds(95, 7, 66, 21);
		panel.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(273, 7, 66, 21);
		panel.add(textField_1);
		textField_1.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(31, 108, 385, 116);
		panel.add(scrollPane);

		table_1 = new JTable();
		String col[] = { "\u6237\u53F7", "\u59D3\u540D", "\u6027\u522B", "ID\u53F7", "\u6237\u5740",
				"\u8FC1\u5165\u65F6\u95F4" };// ���ñ�ͷ
		// ����Model��ű�ͷ 0��ʾrowcount ����������
		DefaultTableModel defaultTableModel = new DefaultTableModel(col, 0);
		table_1.setModel(defaultTableModel);// ��������model
		scrollPane.setViewportView(table_1);// ���ñ���ɼ���
		JButton btnNewButton = new JButton("\u786E\u5B9A");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				defaultTableModel.getDataVector().clear();// ��ձ����������
				String name1 = textField.getText();
				String id1 = textField_1.getText();
				String huhao1 = null;
				// ����sList�÷��ͼ��ϵ����ݣ��������ݷ���strRow�����У�ÿ�����ݣ�
				if (list.size() > 0) {
					for (int i = 0; i < list.size(); i++) {
						Person p = list.get(i);
						if (name1.equals(p.getName()) && id1.equals(p.getID())) {
							// ��ȡ����
							huhao1 = p.getHuhao();
							for (int j = 0; j < list.size(); j++) {
								Person p1 = list.get(j);
								if (huhao1.equals(p1.getHuhao())) {
									String huhao = list.get(j).getHuhao();
									String name = list.get(j).getName();
									String sex = list.get(j).getSex();
									String id = list.get(j).getID();
									String huzhi = list.get(j).getHuzhi();
									String date = list.get(j).getDate();
									String[] strRow = { huhao, name, sex, id, huzhi, date };

									// ����������
									defaultTableModel.addRow(strRow);
								} else {
									continue;
								}
							}
							table_1.setModel(defaultTableModel);
							scrollPane.setViewportView(table_1);

							return;
						}
						if (i == list.size() - 1) {
							JOptionPane.showMessageDialog(null, "������Ϣ����������Ա������", "����", JOptionPane.ERROR_MESSAGE);
						}
					}
				} else {
					JOptionPane.showMessageDialog(null, "û������", "����", JOptionPane.ERROR_MESSAGE);

				}

			}
		});
		btnNewButton.setBounds(31, 59, 97, 23);
		panel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("����");
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new AdminDL().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(303, 59, 97, 23);
		panel.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("\u91CD\u7F6E");
		btnNewButton_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
			}
		});
		btnNewButton_2.setBounds(168, 59, 97, 23);
		panel.add(btnNewButton_2);

	}
}
