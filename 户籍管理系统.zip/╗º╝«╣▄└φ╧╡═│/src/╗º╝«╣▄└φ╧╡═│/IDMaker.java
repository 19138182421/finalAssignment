package ��������ϵͳ;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class IDMaker extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2787406004318442775L;
	private JPanel contentPane;
	private JTable table;
	String[] s = null;

	/**
	 * Create the frame.
	 */
	FileReader fr = null;
	BufferedReader br = null;

	public IDMaker() {
		setTitle("\u8EAB\u4EFD\u8BC1\u529E\u7406");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 250, 560, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(0, 10, 545, 173);
		contentPane.add(scrollPane);

		table = new JTable();
		table.setEnabled(false);
		String col[] = { "\u59D3\u540D", "\u6027\u522B", "\u6C11\u65CF", "\u51FA\u751F\u65E5\u671F", "\u4F4F\u5740",
				"\u8EAB\u4EFD\u8BC1\u53F7", "\u8054\u7CFB\u7535\u8BDD" };// ���ñ�ͷ
		// ����Model��ű�ͷ 0��ʾrowcount ����������
		DefaultTableModel defaultTableModel = new DefaultTableModel(col, 0);
		table.setModel(defaultTableModel);// ��������model
		try {
			fr = new FileReader("D:\\ID.txt");
			br = new BufferedReader(fr);
			String Line = "";
			while ((Line = br.readLine()) != null) {
				s = Line.split(" ");
				defaultTableModel.addRow(s);
			}

			fr.close();
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		table.setModel(defaultTableModel);

		scrollPane.setViewportView(table);

		JButton btnNewButton = new JButton("\u5168\u90E8\u529E\u7406");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				/* ���幦���ɴ�ӡ��ʵ�� */
				JOptionPane.showMessageDialog(null, "��ӡ�ɹ� ��ǰ����ӡ����ȡ��", "��ʾ��Ϣ", JOptionPane.PLAIN_MESSAGE);
				// ����ļ�
				File file = new File("D:\\ID.txt");
				if (file.exists()) {
					file.delete();
				}
				try {
					file.createNewFile();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(75, 212, 97, 41);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u8FD4\u56DE");
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new AdminDL().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(257, 212, 97, 41);
		contentPane.add(btnNewButton_1);
	}

}
