package ��������ϵͳ;

import static ��������ϵͳ.Filemain.list;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Modify extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 396481936763035173L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTable table;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTable table_1;
	private int count;

	/**
	 * Create the frame.
	 */
	public Modify() {
		setTitle("\u4FEE\u6539\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 180, 700, 500);
		contentPane = new JPanel();
		contentPane.setToolTipText("");
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u59D3\u540D");
		lblNewLabel.setBounds(39, 28, 58, 15);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("ID\u53F7");
		lblNewLabel_1.setBounds(195, 28, 58, 15);
		contentPane.add(lblNewLabel_1);

		textField = new JTextField();
		textField.setBounds(74, 25, 66, 21);
		contentPane.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(242, 25, 66, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(39, 117, 603, 61);
		contentPane.add(scrollPane);

		table = new JTable();
		String col[] = { "\u6237\u53F7", "\u59D3\u540D", "\u6027\u522B", "ID\u53F7", "\u6237\u5740", "\u5907\u6CE8" };
		DefaultTableModel defaultTableModel = new DefaultTableModel(col, 0);
		table.setModel(defaultTableModel);
		scrollPane.setViewportView(table);
		JButton btnNewButton = new JButton("\u786E\u8BA4");// ȷ��
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				defaultTableModel.getDataVector().clear();
				String name1 = textField.getText();
				String id1 = textField_1.getText();
				if (list.size() > 0) {
					for (int i = 0; i < list.size(); i++) {
						Person p = list.get(i);
						if (name1.equals(p.getName()) && id1.equals(p.getID())) {
							count = i;
							String huhao = list.get(i).getHuhao();
							String name = list.get(i).getName();
							String sex = list.get(i).getSex();
							String id = list.get(i).getID();
							String huzhi = list.get(i).getHuzhi();
							String date = list.get(i).getDate();
							String[] strRow = { huhao, name, sex, id, huzhi, date };

							// ����������
							defaultTableModel.addRow(strRow);
							table.setModel(defaultTableModel);
							scrollPane.setViewportView(table);

							return;
						}
						if (i == list.size() - 1) {
							JOptionPane.showMessageDialog(null, "δ����������Ա��Ϣ", "����", JOptionPane.ERROR_MESSAGE);
						}
					}
				} else {
					JOptionPane.showMessageDialog(null, "û������", "����", JOptionPane.ERROR_MESSAGE);

				}

			}
		});
		btnNewButton.setBounds(425, 24, 97, 23);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u8FD4\u56DE");// ����
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new AdminDL().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(425, 57, 97, 23);
		contentPane.add(btnNewButton_1);

		textField_2 = new JTextField();
		textField_2.setBounds(39, 209, 66, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);

		textField_3 = new JTextField();
		textField_3.setBounds(150, 209, 66, 21);
		contentPane.add(textField_3);
		textField_3.setColumns(10);

		textField_4 = new JTextField();
		textField_4.setBounds(253, 209, 66, 21);
		contentPane.add(textField_4);
		textField_4.setColumns(10);

		textField_5 = new JTextField();
		textField_5.setBounds(359, 209, 66, 21);
		contentPane.add(textField_5);
		textField_5.setColumns(10);

		textField_6 = new JTextField();
		textField_6.setBounds(466, 209, 66, 21);
		contentPane.add(textField_6);
		textField_6.setColumns(10);

		textField_7 = new JTextField();
		textField_7.setBounds(567, 209, 66, 21);
		contentPane.add(textField_7);
		textField_7.setColumns(10);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(39, 330, 603, 71);
		contentPane.add(scrollPane_1);

		table_1 = new JTable();
		String col1[] = { "\u6237\u53F7", "\u59D3\u540D", "\u6027\u522B", "ID\u53F7", "\u6237\u5740", "\u5907\u6CE8" };
		DefaultTableModel defaultTableModel1 = new DefaultTableModel(col1, 0);
		table_1.setModel(defaultTableModel1);
		scrollPane_1.setViewportView(table_1);
		JButton btnNewButton_2 = new JButton("\u786E\u8BA4\u4FEE\u6539");// ȷ���޸�
		btnNewButton_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean bool = true;
				String s2 = textField_2.getText();
				String s3 = textField_3.getText();
				String s4 = textField_4.getText();
				String s5 = textField_5.getText();
				String s6 = textField_6.getText();
				String s7 = textField_7.getText();
				System.out.print(s2 + s3 + s4 + s5 + s6 + s7);
				if (textField_2.getText().equals("") || textField_3.getText().equals("")
						|| textField_4.getText().equals("") || textField_5.getText().equals("")
						|| textField_6.getText().equals("") || textField_7.getText().equals("")) {
					bool = false;
				}

				if (bool) {
					Person p = list.get(count);
					p.setHuhao(s2);
					p.setName(s3);
					p.setSex(s4);
					p.setID(s5);
					p.setHuzhi(s6);
					p.setDate(s7);
					list.set(count, p);
					String[] strRow = { s2, s3, s4, s5, s6, s7 };
					System.out.print(s2 + s3 + s4 + s5 + s6 + s7);
					// ����������
					defaultTableModel1.addRow(strRow);
					table_1.setModel(defaultTableModel1);
					scrollPane_1.setViewportView(table_1);

					new Filew().writePer();
					JOptionPane.showMessageDialog(btnNewButton_2, "�޸ĳɹ�"); // ��Ϣ�Ի���
				} else {
					JOptionPane.showMessageDialog(btnNewButton_2, " ������������Ϣ"); // ��Ϣ�Ի���
				}
			}
		});
		btnNewButton_2.setBounds(253, 278, 97, 23);
		contentPane.add(btnNewButton_2);

	}
}
