package ��������ϵͳ;

import static ��������ϵͳ.Filemain.list1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class ZhuCe extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3187101001440688308L;
	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	String w[] = null;
	boolean bool = true;

	public ZhuCe() {
		setTitle("\u6CE8\u518C\u7528\u6237\u4FE1\u606F");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 250, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u8D26 \u53F7\uFF1A");
		lblNewLabel.setBounds(118, 70, 58, 15);
		contentPane.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\u5BC6 \u7801\uFF1A");
		lblNewLabel_1.setBounds(118, 107, 58, 15);
		contentPane.add(lblNewLabel_1);

		textField = new JTextField();
		textField.setBounds(161, 67, 132, 21);
		contentPane.add(textField);
		textField.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setBounds(161, 104, 132, 21);
		contentPane.add(passwordField);

		JButton btnNewButton = new JButton("\u786E\u8BA4");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				for (int i = 0; i < list1.size(); i++) {
					w = list1.get(i).split(" ");
					if (w[0].equals(textField.getText())) {
						bool = false;
						break;
					} else {
						bool = true;
					}

				}
				if (bool) {
					user();
				} else {
					JOptionPane.showMessageDialog(null, "�û���ע�� \n�뷵�ص�¼��", "��ʾ��Ϣ", JOptionPane.ERROR_MESSAGE);

				}
			}
		});
		btnNewButton.setBounds(118, 179, 90, 23);
		contentPane.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u8FD4\u56DE\u767B\u5F55");
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new MainGui().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(231, 179, 92, 23);
		contentPane.add(btnNewButton_1);

		JCheckBox chckbxNewCheckBox = new JCheckBox("\u663E\u793A\u5BC6\u7801");
		chckbxNewCheckBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					passwordField.setEchoChar((char) 0);
				} else {
					// ��������������ڸ�Ϊ*��
					passwordField.setEchoChar('*');
				}
			}
		});
		chckbxNewCheckBox.setBounds(303, 107, 109, 23);
		contentPane.add(chckbxNewCheckBox);

	}

	protected void user() {

		FileWriter out = null;
		try {
			out = new FileWriter("D:\\t2.txt", true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedWriter bufferWrite = new BufferedWriter(out);
		/* String���������ն�ȡ������ */
		String str = null;
		str = textField.getText() + " " + String.valueOf(passwordField.getPassword());
		try {
			bufferWrite.newLine();
			bufferWrite.write(str);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			bufferWrite.close();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JOptionPane.showMessageDialog(null, "ע��ɹ���", "��ʾ��Ϣ", JOptionPane.PLAIN_MESSAGE);
	}

}
