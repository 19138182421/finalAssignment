package ��������ϵͳ;

import static ��������ϵͳ.Filemain.list1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class ChPassword {
	private JTextField textField;
	private JPasswordField passwordField;

	public ChPassword() {
		initialize();
	}

	private void initialize() {
		JFrame frame = new JFrame();
		frame.setVisible(true);
		frame.setBounds(500, 250, 450, 300);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 390, 243);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u8D26\u53F7\uFF1A");
		lblNewLabel.setBounds(33, 54, 58, 15);
		panel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\u5BC6\u7801\uFF1A");
		lblNewLabel_1.setBounds(33, 93, 58, 15);
		panel.add(lblNewLabel_1);

		textField = new JTextField();
		textField.setBounds(73, 51, 119, 21);
		panel.add(textField);
		textField.setColumns(10);

		passwordField = new JPasswordField();
		passwordField.setBounds(73, 90, 119, 21);
		panel.add(passwordField);

		JButton btnNewButton = new JButton("ȷ���޸�");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String s1 = textField.getText();
				String s2 = String.valueOf(passwordField.getPassword());
				String str = s1 + " " + s2;
				String str1 = null;
				String word[] = null;
				if (list1.size() > 0) {
					for (int j = 0; j < list1.size(); j++) {
						str1 = list1.get(j);
						word = str1.split(" ");
						if (s1.equals(word[0])) {
							list1.remove(j);
							list1.add(str);
							new Filew().writeUse();
							JOptionPane.showMessageDialog(null, "�����޸ĳɹ���", "��ʾ��Ϣ", JOptionPane.PLAIN_MESSAGE);
							return;
						}
					}
				} else {
					JOptionPane.showMessageDialog(null, "�����޸�ʧ��", "��ʾ��Ϣ", JOptionPane.ERROR_MESSAGE);
				}

				for (int i = 0; i < list1.size(); i++) {
					System.out.println(list1.get(i));
				}
			}
		});
		btnNewButton.setBounds(43, 174, 97, 23);
		panel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u8FD4\u56DE\u767B\u5F55");
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new MainGui().setVisible(true);
				frame.dispose();
			}
		});
		btnNewButton_1.setBounds(211, 174, 97, 23);
		panel.add(btnNewButton_1);

		JCheckBox chckbxNewCheckBox = new JCheckBox("\u663E\u793A/\u9690\u85CF\u5BC6\u7801");
		chckbxNewCheckBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					passwordField.setEchoChar((char) 0);
				} else {
					// ��������������ڸ�Ϊ*��
					passwordField.setEchoChar('*');
				}
			}
		});
		chckbxNewCheckBox.setBounds(199, 89, 109, 23);
		panel.add(chckbxNewCheckBox);

	}
}
