package ��������ϵͳ;

import static ��������ϵͳ.Filemain.fa;
import static ��������ϵͳ.Filemain.fe;
import static ��������ϵͳ.Filemain.list;
import static ��������ϵͳ.Filemain.list1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Filemain {
	/*
	 * ��ȡ�ļ��û���Ϣ
	 */
	static List<Person> list = new ArrayList<Person>();
	static List<String> list1 = new ArrayList<String>();
	static String fa = "D:\\t2.txt";
	static String fe = "D:\\PersonData.txt";// �ļ���
	static {
		File file, file1;
		file = new File(fe);
		file1 = new File(fa);
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (!file1.exists()) {
			try {
				file1.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		// �������Ѿ��ɹ������ļ��������Ǵ������ļ�
		// ���ļ��е����ݶ������
		FileReader fr = null;
		BufferedReader br = null;
		FileReader fr1 = null;
		BufferedReader br1 = null;
		try {
			fr = new FileReader(fe);
			br = new BufferedReader(fr);
			String Line = "";
			while ((Line = br.readLine()) != null) {
				String[] s = Line.split(" ");
				Person p = new Person();
				p.setHuhao(s[0]);
				p.setName(s[1]);
				p.setSex(s[2]);
				p.setID(s[3]);
				p.setHuzhi(s[4]);
				p.setDate(s[5]);
				list.add(p);
			}

			fr.close();
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			fr1 = new FileReader(fa);
			br1 = new BufferedReader(fr1);
			String Line = "";
			while ((Line = br1.readLine()) != null) {
				list1.add(Line);

			}

			fr1.close();
			br1.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String args[]) {
		new MainGui().setVisible(true);
	}
}
/*
 * д���ļ�
 */

class Filew { // ������Ϣ���ļ���

	public void writePer(Person p) { // ׷��д��ָ����Ϣ
		try {
			FileWriter fw = new FileWriter(fe, true);
			BufferedWriter bw = new BufferedWriter(fw);
			if (!list.isEmpty()) {
				bw.newLine();
			}
			bw.write(p.getHuhao() + " " + p.getName() + " " + p.getSex() + " " + p.getID() + " " + p.getHuzhi() + " "
					+ p.getDate());
			bw.close();
			fw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void writePer() { // ȫ������д�뼯���е�ǰ��Ϣ
		try {
			FileWriter fw = new FileWriter(fe);
			BufferedWriter bw = new BufferedWriter(fw);
			for (int i = 0; i < list.size(); i++) {
				Person p = list.get(i);
				bw.write(p.getHuhao() + " " + p.getName() + " " + p.getSex() + " " + p.getID() + " " + p.getHuzhi()
						+ " " + p.getDate());
				if (i != list.size() - 1) {
					bw.newLine();
				}
			}
			bw.close();
			fw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void writeUse() { // ȫ������д�뼯���е�ǰ��Ϣ
		try {
			FileWriter fw = new FileWriter(fa);
			BufferedWriter bw = new BufferedWriter(fw);
			for (int i = 0; i < list1.size(); i++) {
				String str = list1.get(i);
				bw.write(str);
				if (i != list.size() - 1) {
					bw.newLine();
				}
			}
			bw.close();
			fw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void writeID(String str) {
		// TODO Auto-generated method stub
		try {
			FileWriter fw = new FileWriter("D:\\ID.txt", true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(str);
			bw.newLine();
			bw.close();
			fw.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
