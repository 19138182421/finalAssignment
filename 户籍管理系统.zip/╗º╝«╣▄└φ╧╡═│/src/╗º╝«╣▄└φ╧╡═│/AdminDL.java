package ��������ϵͳ;

import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class AdminDL extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7075782806065848410L;
	private JPanel contentPane;

	public AdminDL() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\yang\\Pictures\\Camera Roll\\heisewenli-2.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(450, 180, 644, 466);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setTitle("\u7BA1\u7406\u5458\u754C\u9762");
		getContentPane().setLayout(null);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u6B22\u8FCE\u8FDB\u5165\u6237\u7C4D\u7BA1\u7406\u4FE1\u606F\u7CFB\u7EDF");// ��ӭ
		lblNewLabel.setForeground(new Color(0, 0, 128));
		lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));
		lblNewLabel.setBounds(174, 10, 256, 45);
		getContentPane().add(lblNewLabel);

		JButton btnNewButton = new JButton("\u6DFB\u52A0");// ����
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Add().setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(95, 98, 114, 40);
		getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u4FEE\u6539");// �޸�
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Modify().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(420, 101, 107, 34);
		getContentPane().add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("\u5220\u9664");// ɾ��
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Delete().setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(95, 311, 114, 40);
		getContentPane().add(btnNewButton_2);

		JButton btnNewButton_4 = new JButton("\u67E5\u8BE2");// ��ѯ
		btnNewButton_4.setBackground(Color.WHITE);
		btnNewButton_4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Inquiry().setVisible(true);
				dispose();
			}
		});
		btnNewButton_4.setBounds(249, 158, 114, 40);
		getContentPane().add(btnNewButton_4);

		JButton btnNewButton_5 = new JButton("ͳ��");// ����
		btnNewButton_5.setBackground(Color.WHITE);
		btnNewButton_5.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new Printf().setVisible(true);
				dispose();
			}
		});
		btnNewButton_5.setBounds(249, 244, 114, 40);
		contentPane.add(btnNewButton_5);

		JLabel lblNewLabel_2 = new JLabel("\u9000\u51FA\u7CFB\u7EDF");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		lblNewLabel_2.setBackground(Color.CYAN);
		lblNewLabel_2.setForeground(Color.BLUE);
		lblNewLabel_2.setBounds(565, 12, 55, 45);
		contentPane.add(lblNewLabel_2);

		JButton btnNewButton_6 = new JButton("\u8EAB\u4EFD\u8BC1\u529E\u7406");
		btnNewButton_6.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				new IDMaker().setVisible(true);
				dispose();
			}
		});
		btnNewButton_6.setBackground(Color.WHITE);
		btnNewButton_6.setForeground(Color.BLACK);
		btnNewButton_6.setBounds(420, 311, 107, 40);
		contentPane.add(btnNewButton_6);

		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(null);
		lblNewLabel_1.setBounds(-502, -51, 1132, 480);
		contentPane.add(lblNewLabel_1);

	}
}
