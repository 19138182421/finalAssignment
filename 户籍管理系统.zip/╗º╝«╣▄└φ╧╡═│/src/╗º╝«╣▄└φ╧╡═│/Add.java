package ��������ϵͳ;

import static ��������ϵͳ.Filemain.list;

import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class Add extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5555492512954481304L;
	protected static final String Filemain = null;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;

	/**
	 * Create the frame.
	 */
	public Add() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\yang\\Pictures\\Camera Roll\\heisewenli-2.jpg"));
		setTitle("\u6DFB\u52A0\u6210\u5458\u4FE1\u606F");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 250, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(34, 10, 370, 253);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNewLabel = new JLabel("\u6237    \u53F7\uFF1A");
		lblNewLabel.setBounds(57, 41, 68, 15);
		panel.add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("\u59D3    \u540D\uFF1A");
		lblNewLabel_1.setBounds(57, 66, 68, 15);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("\u6027    \u522B\uFF1A");
		lblNewLabel_2.setBounds(57, 91, 68, 15);
		panel.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("ID    \u53F7\uFF1A");
		lblNewLabel_3.setBounds(57, 116, 81, 15);
		panel.add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("\u6237    \u5740\uFF1A");
		lblNewLabel_4.setBounds(57, 141, 68, 15);
		panel.add(lblNewLabel_4);

		JLabel lblNewLabel_5 = new JLabel("\u8FC1\u5165\u65F6\u95F4\uFF1A");
		lblNewLabel_5.setBounds(57, 166, 81, 15);
		panel.add(lblNewLabel_5);

		textField = new JTextField();
		textField.setBounds(118, 38, 143, 21);
		panel.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(118, 63, 143, 21);
		panel.add(textField_1);

		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(118, 88, 143, 21);
		panel.add(textField_2);

		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(118, 113, 143, 21);
		panel.add(textField_3);

		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(118, 138, 143, 21);
		panel.add(textField_4);

		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(118, 163, 143, 21);
		panel.add(textField_5);

		JButton btnNewButton = new JButton("\u4FDD\u5B58");
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String s1 = textField.getText();
				String s2 = textField_1.getText();
				String s3 = textField_2.getText();
				String s4 = textField_3.getText();
				String s5 = textField_4.getText();
				String s6 = textField_5.getText();
				Person p = new Person(s1, s2, s3, s4, s5, s6);
				boolean bool = true;
				for (Person st : list) {
					if (st.getID().equals(s4)) {
						JOptionPane.showMessageDialog(null, "�Ѵ���,���ٴ�ȷ����Ϣ", "����", JOptionPane.ERROR_MESSAGE);
						bool = false;
						return;
					}
				}

				if (textField.getText().equals("") || textField_1.getText().equals("")
						|| textField_2.getText().equals("") || textField_3.getText().equals("")
						|| textField_4.getText().equals("") || textField_5.getText().equals("")) {
					JOptionPane.showMessageDialog(null, "��������������Ϣ", "����", JOptionPane.ERROR_MESSAGE);
					bool = false;
				}

				if (bool) {
					JOptionPane.showMessageDialog(btnNewButton, "���ӳɹ�"); // ��Ϣ�Ի���

					list.add(p);

					new Filew().writePer(p);

					textField.setText("");
					textField_1.setText("");
					textField_2.setText("");
					textField_3.setText("");
					textField_4.setText("");
					textField_5.setText("");

				} else {
					JOptionPane.showMessageDialog(null, "���Ӵ���", "����", JOptionPane.ERROR_MESSAGE);
				}

			}
		});
		btnNewButton.setBounds(57, 208, 97, 35);
		panel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("ȡ��");
		btnNewButton_1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				new AdminDL().setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(182, 208, 97, 35);
		panel.add(btnNewButton_1);

	}
}
