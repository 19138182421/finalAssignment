package ��������ϵͳ;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class MainGui extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4293805016058460117L;
	private JLayeredPane contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	JRadioButton rdbtnNewRadioButton = null;
	JRadioButton rdbtnNewRadioButton_1 = null;

	public MainGui() {
		init();
	}

	private void init() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\yang\\Pictures\\Camera Roll\\heisewenli-2.jpg"));
		setTitle("\u6237\u7C4D\u7BA1\u7406\u4FE1\u606F\u7CFB\u7EDF1.0");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 250, 450, 300);
		contentPane = new JLayeredPane();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 456, 263);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel �˺� = new JLabel("\u8D26\u53F7\uFF1A");
		�˺�.setBounds(85, 63, 58, 15);
		panel.add(�˺�);

		JLabel lblNewLabel = new JLabel("\u5BC6\u7801\uFF1A");
		lblNewLabel.setBounds(85, 99, 58, 15);
		panel.add(lblNewLabel);

		textField = new JTextField();// �˺ſ�
		textField.setOpaque(false);// ͸��
		textField.setBounds(122, 60, 185, 21);
		panel.add(textField);
		textField.setColumns(10);

		passwordField = new JPasswordField();// �����
		passwordField.setOpaque(false);
		passwordField.setBounds(122, 96, 185, 21);
		panel.add(passwordField);

		rdbtnNewRadioButton = new JRadioButton("\u7528\u6237");// �û���ť
		rdbtnNewRadioButton.setBorder(null); // ���߿�
		// rdbtnNewRadioButton.setOpaque(false);//��Ĭ�ϱ���
		rdbtnNewRadioButton.setContentAreaFilled(false);// ��Ĭ�ϱ���
		rdbtnNewRadioButton.setFocusPainted(false);// ������߿�
		rdbtnNewRadioButton.setForeground(Color.BLACK);
		rdbtnNewRadioButton.setBackground(Color.WHITE);
		buttonGroup.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.setBounds(103, 139, 63, 23);
		panel.add(rdbtnNewRadioButton);

		rdbtnNewRadioButton_1 = new JRadioButton("\u7BA1\u7406\u5458");// ����Ա��ť
		rdbtnNewRadioButton_1.setBorder(null);
		rdbtnNewRadioButton_1.setContentAreaFilled(false);
		rdbtnNewRadioButton_1.setFocusPainted(false);
		rdbtnNewRadioButton_1.setVerticalAlignment(SwingConstants.TOP);
		buttonGroup.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.setBounds(185, 139, 83, 23);
		panel.add(rdbtnNewRadioButton_1);

		JButton btnNewButton = new JButton("\u767B\u5F55");// ��¼��ť
		btnNewButton.addActionListener(this);
		btnNewButton.setBounds(85, 194, 97, 23);
		btnNewButton.setBorder(null);
		// btnNewButton.setContentAreaFilled(false);
		btnNewButton.setFocusPainted(false);
		panel.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\u6CE8\u518C");// ע�ᰴť
		btnNewButton_1.addActionListener(this);
		btnNewButton.setBorder(null);
		// btnNewButton_1.setContentAreaFilled(false);
		btnNewButton_1.setFocusPainted(false);
		btnNewButton_1.setBounds(210, 194, 97, 23);
		panel.add(btnNewButton_1);

		JCheckBox chckbxNewCheckBox = new JCheckBox("\u663E\u793A");// ��ʾ���밴ť
		chckbxNewCheckBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					passwordField.setEchoChar((char) 0);
				} else {
					// ��������������ڸ�Ϊ*��
					passwordField.setEchoChar('*');
				}
			}
		});
		chckbxNewCheckBox.setBorder(null);
		chckbxNewCheckBox.setContentAreaFilled(false);
		chckbxNewCheckBox.setFocusPainted(false);
		chckbxNewCheckBox.setBounds(311, 95, 109, 23);
		panel.add(chckbxNewCheckBox);

		JLabel lblNewLabel_1 = new JLabel("\u5FD8\u8BB0\u5BC6\u7801\uFF1F");
		lblNewLabel_1.setForeground(Color.BLUE);
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new ChPassword();
				dispose();
			}
		});
		lblNewLabel_1.setBounds(348, 221, 77, 19);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("");
		lblNewLabel_1_1
				.setIcon(new ImageIcon("C:\\Users\\yang\\Pictures\\Camera Roll\\QQ\u56FE\u724720191117105313.jpg"));
		lblNewLabel_1_1.setBounds(-13, -84, 615, 401);
		panel.add(lblNewLabel_1_1);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getActionCommand() == "��¼") {
			if (rdbtnNewRadioButton.isSelected()) {
				// System.out.print(textField.getText()); // �û���¼
				user();
			} else if (rdbtnNewRadioButton_1.isSelected()) {
				// System.out.print(passwordField.getText()); // ����Ա��¼
				admin();
			} else if (!rdbtnNewRadioButton.isSelected()) {
				JOptionPane.showMessageDialog(null, "��ȷ��Ȩ�ޣ�", "��ʾ��Ϣ", JOptionPane.ERROR_MESSAGE);
			}
		} else if (e.getActionCommand() == "ע��") {
			new ZhuCe().setVisible(true);
			dispose();
		}
	}

	protected void admin() { // ����Ա��¼������ת // TODO Auto-generated method stub
		if (textField.getText().equals("1") && String.valueOf(passwordField.getPassword()).equals("1")) {
			JOptionPane.showMessageDialog(null, "����Ա��¼�ɹ���", "��ʾ��Ϣ", JOptionPane.PLAIN_MESSAGE);
			new AdminDL().setVisible(true);
			dispose();
		} else {
			JOptionPane.showMessageDialog(null, "�˺Ż����������\n����������", "��ʾ��Ϣ", JOptionPane.ERROR_MESSAGE);
		}
	}

	protected void user() { // �û���¼������ת
		FileReader fread = null;
		// String str1 = null;
		try {
			fread = new FileReader("D:\\t2.txt");
		} catch (FileNotFoundException e1) {

			e1.printStackTrace();
		}
		try {
			BufferedReader in = new BufferedReader(fread);
			String str = null;
			String words[] = null;
			while ((str = in.readLine()) != null) {
				// str1 = str;
				words = str.split(" ");
				if (words[0].equals(textField.getText())) {
					// str1 = null;
					break;
				}

			}
			if (words[0].equals(textField.getText()) && words[1].equals(String.valueOf(passwordField.getPassword()))) {
				JOptionPane.showMessageDialog(null, "�û���½�ɹ���", "��ʾ��Ϣ", JOptionPane.PLAIN_MESSAGE);
				new UseInquiry().setVisible(true);
				dispose();
			} else {
				JOptionPane.showMessageDialog(null, "�˺Ż�������������δע�ᣡ\n����������", "��ʾ��Ϣ", JOptionPane.ERROR_MESSAGE);
			}

		} catch (IOException e) {
			System.out.println("Error" + e.toString());

		}

	}
}
